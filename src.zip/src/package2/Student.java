package package2;

import java.util.Arrays;

public class Student{
    private String studentID; //Holds the ID of each student
    private static String[] list = new String[0]; //Array holding all student IDs for comparrison

    //Initializes a new student and adds then to the array
    public Student(String studentID){
        this.studentID = studentID;
        int n = list.length;
        String[] newList = new String[n+1];
        for(int i = 0; i < n; i++){
            newList[i] = list[i];
        }
        newList[n] = this.studentID;
        list = new String[n+1];
        for(int i = 0; i < list.length; i++){
            list[i] = newList[i];
        }
    }

    //Returns the ID of the specified student as a string
    public String toString(){
        return studentID;
    }
    //Returns the array of students as a string
    public static String List(){
        return Arrays.toString(list);
    }
    
}
