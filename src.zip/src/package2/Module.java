package package2;

import java.util.Arrays;

public class Module{
    private String moduleID; //Holds the ID of each module
    private Student[] classList; //Array of students in each class
    private Integer classSize; //Integer holding the number of students in each class

    //Initializes a new module
    public Module(String moduleID){
        this.moduleID = moduleID;
        this.classList = new Student[5];
        this.classSize = 0;
    }

    //Returns the class array for the specified module as a string
    public String toString(){
        String output = "Module: ";
        output += this.moduleID;
        output += "\n";
        output += Arrays.toString(this.classList);
        return output;
    }

    //Function to enrol students
    public void enrol(Student s){
        //Adds student to the next open spot of the class array
        for(int i = 0; i < this.classList.length; i++){
            if(this.classList[i] != s){
                if(this.classList[i] == null){
                    this.classList[i] = s;
                    this.classSize++;
                    break;
                }
            }
        }
        //Orders the class array by student ID
        for(int i = 0; i < this.classList.length - 1; i++){
            if(this.classList[i+1] != null){
                Student currentStudent = this.classList[i];
                int currentStudentNum = Integer.parseInt(this.classList[i].toString().substring(this.classList[i].toString().length() - 1));
                Student nextStudent = this.classList[i+1];
                int nextStudentNum = Integer.parseInt(this.classList[i+1].toString().substring(this.classList[i+1].toString().length() - 1));
                if(nextStudentNum < currentStudentNum){
                    this.classList[i] = nextStudent;
                    this.classList[i+1] = currentStudent;
                }
            }
        }
    }
    //Function to unenrol a student
    public void unenrol(Student s){
        //Adds all the students not unenrolling to a new array in the same order
        Student[] tempList = new Student[5];
        for(int i = 0; i < this.classList.length; i++){
            if(this.classList[i] != s){
                for(int j = 0; j < tempList.length; j++){
                    if(tempList[j] == null){
                        tempList[j] = this.classList[i];
                        break;
                    }
                }
            }
        }
        //Replacing the old class array with the new one
        for(int i = 0; i < this.classList.length; i++){
            this.classList[i] = tempList[i];
        }
    }
}
